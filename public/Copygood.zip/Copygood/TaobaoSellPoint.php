<?php
class TaobaoSellPoint implements SellPointStrategy
{
    public function getSellPoint()
    {

    }
}
