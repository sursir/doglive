<?php
namespace Taobao;

/**
 * @author taobao 2011-5-25 下午03:00:01
 */
class TaobaoQuery {

	private $sysParams = array(); //系统参数
	private $apiParams = array(); //API参数
	private $topAppkey;
	private $topAppSecret;
	private $topSession;
	private $topUrl;

	/**
	 * @param $method
	 * @param $format
	 */

	function TaobaoQuery($method, $format = 'json'){
		$this->sysParams['method'] = $method;
		$this->sysParams['format'] = $format;
		$this->topUrl = 'http://gw.api.taobao.com/router/rest';
		//$this->topUrl = 'http://223.4.23.242/trans/wrapindex.php';
		//$this->topUrl = 'http://gw.api.tbsandbox.com/router/rest';
		$this->topAppkey = '12296117';
		$this->topAppSecret = '76c30d12fd1d5973981a6d1b7495b392';

		//$this->topAppSecret ='sandboxb9f060d7279187abf263f5fc9';
		$this->topSession = '5062137d4444c4532771521808f1c81c070675410055fy7uA2CT89882';
	}

	/**
	 * 设置API参数
	 * @param $key
	 * @param $val
	 */
	function setParam($key, $val){
		if ( $val != null ) {
			$this->apiParams[$key] = $val;
		}
	}

	/**
	 * 返回API参数
	 * @param $key
	 * @param $defaultValue
	 */
	function getParam($key, $defaultValue = ""){
		if ( array_key_exists($key, $this->apiParams) ) {
			return $this->apiParams[$key];
		} else {
			return $defaultValue;
		}
	}

	/**
	 * @return the $sysParams
	 */
	public function getSysParams(){
		return $this->sysParams;
	}

	/**
	 * @return the $apiParams
	 */
	public function getApiParams(){
		return $this->apiParams;
	}

	/**
	 * @param $sysParams the $sysParams to set
	 */
	public function setSysParams($sysParams){
		$this->sysParams = $sysParams;
	}

	/**
	 * @param $apiParams the $apiParams to set
	 */
	public function setApiParams($apiParams){
		$this->apiParams = $apiParams;
	}
	/**
	 * @return the $topAppkey
	 */
	public function getTopAppkey(){
		return $this->topAppkey;
	}

	/**
	 * @return the $topSession
	 */
	public function getTopSession(){
		return $this->topSession;
	}

	/**
	 * @param $topAppkey the $topAppkey to set
	 */
	public function setTopAppkey($topAppkey){
		$this->topAppkey = $topAppkey;
	}

	/**
	 * @param $topSession the $topSession to set
	 */
	public function setTopSession($topSession){
		$this->topSession = $topSession;
	}
	/**
	 * @return the $topAppSecret
	 */
	public function getTopAppSecret(){
		return $this->topAppSecret;
	}

	/**
	 * @param $topAppSecret the $topAppSecret to set
	 */
	public function setTopAppSecret($topAppSecret){
		$this->topAppSecret = $topAppSecret;
	}
	/**
	 * @return the $topUrl
	 */
	public function getTopUrl(){
		return $this->topUrl;
	}

	/**
	 * @param $topUrl the $topUrl to set
	 */
	public function setTopUrl($topUrl){
		$this->topUrl = $topUrl;
	}


}

?>