<?php
interface SellPointStrategy
{
    public function sellPoint();
}
