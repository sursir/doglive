<?php
/**
 * Content: 批量修改标题
 * User: ldl 修改
 * Date: 2015/6/3 13:00:00
 */

 // [SERVER_NAME] => 121.199.162.194
 // [SERVER_ADDR] => 121.199.162.194
$hostname = $_SERVER['SERVER_ADDR'];//服务器地址
// $hndir = '';
// if($hostname == '121.199.162.194'){
//     $hndir = 'http://'.$hostname.'/webhuoniu/';
// }else{
//     $hndir ='http://'.$hostname.'/huoniu/';
// }

$hndir = 'http://121.41.168.185/huoniu/';

$userid = isset($_POST['userid']) ? intval($_POST['userid']) : 0;
$shoptype = isset($_POST['shoptype']) ? trim($_POST['shoptype']) : '';
$session = file_get_contents($hndir.'proxy_getsession.php?uid='.$userid);
$usernick = isset($_POST['usernick']) ? urldecode(trim($_POST['usernick'])) : '';
$postobj = isset($_POST['postobj']) ? $_POST['postobj'] : array();//请求数据

//验证请求参数，如果不对，直接停止操作
if(empty($userid) || empty($session)|| empty($shoptype) || empty($postobj)){
    echo json_encode(array('status'=>600,'info'=>'请求参数错误'));
    exit;
}
$goodid = $postobj['goodid'];//操作的商品id
$handletype = $postobj['handletype'];
define("DIRPATH", dirname(__FILE__));//当前文件路劲
define("AUTODIR", dirname(dirname(__FILE__)));

require DIRPATH.'/taobao_function.php';
require DIRPATH.'/Strlen.php';

//require_once DIRPATH.'/updateDefault.php';

$newidarr = array_chunk($goodid,20);//把id拆分为20个一组
$fields = 'title,pic_url,num,num_iid,outer_id,cid';
$eroor = array();//错误宝贝信息

use Top\schema\factory\SchemaReader;
use Top\schema\factory\SchemaWriter;

foreach($newidarr as $k => $v){
    $numids = implode(',', $v);
    $goodinfolist = get_goods_cid($fields,$numids,$session);//获取宝贝基本信息
    if(isset($goodinfolist['items_seller_list_get_response']) && isset($goodinfolist['items_seller_list_get_response']['items'])){
        $goodinfo = $goodinfolist['items_seller_list_get_response']['items']['item'];
        foreach($goodinfo as $onk =>$onev){//一个宝贝处理
            $title_cid = $onev['cid'];
            $numid = $onev['num_iid'];

            if ($shoptype == 'C') {  //C店
                $goods_rule = get_cshop_goodrule($session, $title_cid, $numid, 'title');
                $one_rule = array();
                if (!isset($goods_rule['item_increment_update_schema_get_response'])) {
                    $eroor[$numid]['userid'] = $userid;
                    $eroor[$numid]['num_iid'] = $numid;
                    $eroor[$numid]['reason'] = '获取标题编辑规则错误C';
                    continue;
                }
                $one_rule = $goods_rule['item_increment_update_schema_get_response']['update_rules'];
            } elseif ($shoptype == 'B') {  //天猫店铺
                $goods_rule = get_good_rule($numid, $session,'title');
              //  print_r($goods_rule);

                if (!isset($goods_rule['tmall_item_increment_update_schema_get_response'])) {
                    $eroor[$numid]['userid'] = $userid;
                    $eroor[$numid]['num_iid'] = $numid;
                    $eroor[$numid]['reason'] = '获取标题编辑规则错误B';
                    continue;
                }
                $one_rule = $goods_rule['tmall_item_increment_update_schema_get_response']['update_item_result'];
            }

            $schemaReader = new SchemaReader;
            $goods_list = $schemaReader->readXmlForList($one_rule);//读取规则变成xml数组
            if(empty($goods_list)){
                $eroor[$numid]['userid'] = $userid;
                $eroor[$numid]['num_iid'] = $numid;
                $eroor[$numid]['reason'] = '读取标题编辑规则错误';
                continue;
            }
            foreach ($goods_list as $key => $v_val) {
                $file_id = $v_val->getId();
                if ($file_id == 'update_fields') {//跟新字段
                    $v_val->setValueWithDefault();//设置value值等于defaultvalue
                    continue;
                }

                if ($file_id == 'title') {//是我们需要操作的字段
                    $type = $v_val->getType();
                    if ($type == 'input') {
                        $default_title = $v_val->getDefaultValue();//取出默认标题
                        $newtitle = updateTitle($postobj,$default_title);

                        if(getDbLen($newtitle) > 30){
                            $eroor[$numid]['userid'] = $userid;
                            $eroor[$numid]['num_iid'] = $numid;
                            $eroor[$numid]['reason'] = '标题超过最大长度，不合法';
                            continue;
                        }
                        $v_val->setValue($newtitle);//设置为最新的值
                    }
                }
            }

            $schemaWriter = new SchemaWriter;
            $new_rule = $schemaWriter->writeParamXml($goods_list);
            if ($shoptype == 'C') {//C店
                $writer = write_cshop_good_desc($numid, $session, $new_rule);
                $result_filed = 'item_schema_increment_update_response';
            } else {
                $result_filed = 'tmall_item_schema_increment_update_response';
                $writer = write_good_desc($numid, $session, $new_rule);
            }

            if (!isset($writer[$result_filed])) {  //修改失败
                $eroor[$numid]['userid'] = $userid;
                $eroor[$numid]['num_iid'] = $numid;
                $eroor[$numid]['reason'] = isset($writer['error_response']) ? $writer['error_response']['sub_msg'] : $writer['error_response']['msg']; 
            }
        }
    }else{
        echo json_encode(array('status'=>600,'info'=>'获取商品信息失败'.implode(',',$goodinfolist['error_response'])));
        exit;
    }
}

if(count($eroor) > 0){
    require DIRPATH.'/mysqlClass.php';
    $db = new MysqlDB();
    $sql = " INSERT INTO `bat_modifyerror`(`userid`,`opid`,`pid`,`baterr`,`username`) VALUES ";
    $time = time();
    $usernick = mysql_real_escape_string($usernick); 
    foreach($eroor as $erk => $erv){
        $insertsql = $sql."($userid,'$time',$erk,'".$erv['reason']."','$usernick')";
        $db->save($insertsql);
    }
    $db->close();
    echo json_encode(array('state'=>800,'info'=>count($eroor).'个宝贝修改失败,请查看修改历史记录'));
}else{
  echo json_encode(array('state'=>800,'info'=>'修改成功'));
}
exit;
//修改类型，要修改的标题，原标题
function updateTitle(&$postobj,$title){
    $handletype = $postobj['handletype'];
    if($handletype == 'addprefix'){//前缀
        $newtitle = $postobj['inputval'].$title;
    }else if($handletype == 'addendfix'){//后缀
        $newtitle = $title.$postobj['inputval'];
    }else if($handletype == 'delsome'){//删除
        $newtitle = str_replace($postobj['inputval'],'',$title);
    }else if($handletype == 'replacesome'){//替换
        $oldval = $postobj['replace_old'];
        $newval = $postobj['replace_new'];
        $newtitle = str_replace($oldval,$newval,$title);
    }else{
        $newtitle = $title;
    }
    return $newtitle;
}

//自动载入文件
function __autoload($className)
{
    $className = str_replace('\\','/',$className);
    $classPath = DIRPATH."/" .$className . '.php';
    if (file_exists($classPath)) {
        require_once($classPath);
    } else {
        echo 'class file' . $classPath . 'not found!';
    }
}