<?php
/**
 * Content:修改价格测试文件
 * User: ldl 修改
 * Date: 2015/6/3 13:00:00
 */

$hostname = $_SERVER['SERVER_ADDR'];//服务器地址

$hndir = 'http://121.41.168.185/huoniu/';

define("BASEDB_HOST", "jconnr74sd4ug.mysql.rds.aliyuncs.com");
define("BASEDB_NAME", "netwaydb");
define("BASEDB_USER", "jusr7m3gaevg");
define("BASEDB_PASSWD", "PixJbj3v97op5M9js");
$nick = '百泰首饰旗舰店';
//$nick = 'jianfang114';
if($nick)
{   
    $conn = ConnetDB();
    $userid = "";
    $nick = mysql_real_escape_string($nick);
    $sql = "select userid,session from act_dxyhq_session where nick='$nick'";
    $strResult= mysql_query($sql) or die("无法获取session记录");
    $info = array();
    if(is_resource($strResult)){
        $rows = mysql_fetch_assoc($strResult);
    }else{
        exit('缺少用户信息');
    }
    mysql_close($conn);
}else{
    die('缺少用户昵称');
}

$userid = $rows['userid'];
$shoptype = 'C';
$session = $rows['session'];
$usernick = $nick;
$numid = '44945031482';//操作的商品id
//$numid = '39766439629';


define("DIRPATH", dirname(__FILE__));//当前文件路劲
define("AUTODIR", dirname(dirname(__FILE__)));

require DIRPATH.'/taobao_function.php';


$eroor = array();//错误宝贝信息
$tmallPrice = array('sku_id'=>'3102620932345', 'price'=>'16350');
$tmallPrice = json_encode($tmallPrice);
$last_pri = '15773';

$field = 'num_iid,price,sku.price,sku.sku_id';
$one_good = search_one_good($session, $field, $numid);//获取一个商品的sku数组


//$res = update_goods_tmall_skus_price($session, $numid, $tmallPrice, $last_pri);


function ConnetDB(){
    $conn = mysql_connect(BASEDB_HOST,BASEDB_USER,BASEDB_PASSWD) or die("cant't link");
    mysql_select_db(BASEDB_NAME,$conn) or die("cant't seldb");
    $sql = "set names utf8";//单引号在cobar 下。一定要去掉 
    mysql_query($sql);
    return $conn;
}

//自动载入文件
function __autoload($className)
{
    $className = str_replace('\\','/',$className);
    $classPath = DIRPATH."/" .$className . '.php';
    if (file_exists($classPath)) {
        require_once($classPath);
    } else {
        echo 'class file' . $classPath . 'not found!';
    }
}