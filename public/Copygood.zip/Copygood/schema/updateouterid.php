<?php
/**
 * Content: 批量修改标题
 * User: ldl 修改
 * Date: 2015/6/3 13:00:00
 */

$hostname = $_SERVER['SERVER_ADDR'];//服务器地址

$hndir = 'http://121.41.168.185/huoniu/';

$userid = isset($_POST['userid']) ? intval($_POST['userid']) : 0;
$shoptype = isset($_POST['shoptype']) ? trim($_POST['shoptype']) : '';
$session = file_get_contents($hndir.'proxy_getsession.php?uid='.$userid);
$usernick = isset($_POST['usernick']) ? urldecode(trim($_POST['usernick'])) : '';
$postobj = isset($_POST['postobj']) ? $_POST['postobj'] : array();//请求数据
$goodid = isset($_POST['goodid']) ? $_POST['goodid'] : array();//操作的商品id
//验证请求参数，如果不对，直接停止操作
if(empty($userid) || empty($session)|| empty($shoptype) || empty($postobj) || empty($goodid)){
    echo json_encode(array('status'=>600,'info'=>'请求参数错误'));
    exit;
}

define("DIRPATH", dirname(__FILE__));//当前文件路劲
define("AUTODIR", dirname(dirname(__FILE__)));

require DIRPATH.'/taobao_function.php';

$newidarr = array_chunk($goodid,20);//把id拆分为20个一组
$fields = 'title,pic_url,num,num_iid,outer_id,cid';
$eroor = array();//错误宝贝信息

use Top\schema\factory\SchemaReader;
use Top\schema\factory\SchemaWriter;

foreach($newidarr as $k => $v){
    $numids = implode(',', $v);
    $goodinfolist = get_goods_cid($fields,$numids,$session);//获取宝贝基本信息
    if(isset($goodinfolist['items_seller_list_get_response']) && isset($goodinfolist['items_seller_list_get_response']['items'])){
        $goodinfo = $goodinfolist['items_seller_list_get_response']['items']['item'];
        foreach($goodinfo as $onk =>$onev){//一个宝贝处理
            $title_cid = $onev['cid'];
            $numid = $onev['num_iid'];
            $auterid = $onev['outer_id'];
            $newauterid = changeouterid($auterid);//获取最新的编码
            if ($shoptype == 'C') {  //C店
                $params['num_iid'] = $numid;
                $params['outer_id'] = $newauterid;
                $updateres = update_good_info($session,$params);
            } elseif ($shoptype == 'B') {  //天猫店铺
                $updateres = update_tmall_outerid($session,$numid,$newauterid);
            }
            if (isset($updateres['error_response'])) {//修改失败
                $eroor[$numid]['userid'] = $userid;
                $eroor[$numid]['num_iid'] = $numid;
                $eroor[$numid]['reason'] = isset($updateres['error_response']['sub_msg']) ? $updateres['error_response']['sub_msg'] : $updateres['error_response']['msg']; 
            }
        }
    }else{
        echo json_encode(array('status'=>600,'info'=>'获取商品信息失败'.implode(',',$goodinfolist['error_response'])));
        exit;
    }
}

if(count($eroor) > 0){
    require DIRPATH.'/mysqlClass.php';
    $db = new MysqlDB();
    $sql = " INSERT INTO `bat_modifyerror`(`userid`,`opid`,`pid`,`baterr`,`username`) VALUES ";
    $time = time();
    $usernick = mysql_real_escape_string($usernick); 
    foreach($eroor as $erk => $erv){
        $insertsql = $sql."($userid,'$time',$erk,'".$erv['reason']."','$usernick')";
        $db->save($insertsql);
    }
    $db->close();
    echo json_encode(array('state'=>800,'info'=>count($eroor).'个宝贝修改失败,请查看修改历史记录'));
}else{
  echo json_encode(array('state'=>800,'info'=>'修改成功'));
}
exit;

//修改编码
function changeouterid($auterid){
    global $postobj;
    $changetype = $postobj['changetype'];//修改类型
    $newauthor = '';
    if($changetype == 'addqianzui'){//前缀
        $newauthor = $postobj['changval'].$auterid;
    }else if($changetype == 'addhouzui'){
        $newauthor = $auterid.$postobj['changval'];
    }else if($changetype == 'delsome'){
        $newauthor = str_replace($postobj['changval'],'',$auterid);
    }else{
        $newauthor = str_replace($postobj['changoldval'],$postobj['changnewval'],$auterid);
    }
    if(empty($newauthor)){
        $newauthor = $auterid;
    }
    return $newauthor;
}

//自动载入文件
function __autoload($className)
{
    $className = str_replace('\\','/',$className);
    $classPath = DIRPATH."/" .$className . '.php';
    if (file_exists($classPath)) {
        require_once($classPath);
    } else {
        echo 'class file' . $classPath . 'not found!';
    }
}