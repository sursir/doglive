<?php
/**
 * Content: 批量修改标题
 * User: ldl 修改
 * Date: 2015/6/3 13:00:00
 */
header("content-type:text/html;charset=utf-8");
error_reporting(E_ALL);
$hostname = $_SERVER['SERVER_ADDR'];//服务器地址
$hndir = 'http://121.41.168.185/huoniu/';
$userid = 877898187;//687179184;
//$userid = isset($_POST['userid']) ? intval($_POST['userid']) : 0;
// $shoptype = isset($_POST['shoptype']) ? trim($_POST['shoptype']) : '';
 $session = file_get_contents($hndir.'proxy_getsession.php?uid='.$userid);
// $usernick = isset($_POST['usernick']) ? urldecode(trim($_POST['usernick'])) : '';
// $changeval = isset($_POST['changval']) ? trim($_POST['changval']) : '';//请求数据
// $goodid = isset($_POST['goodid']) ? $_POST['goodid'] : array();//操作的商品id
// //验证请求参数，如果不对，直接停止操作
// if(empty($userid) || empty($session)|| empty($shoptype)){
//     echo json_encode(array('status'=>600,'info'=>'请求参数错误'));
//     exit;
// }
echo '<pre>';
$shoptype = 'B';
$usernick = 'xxxxx';
//$goodid = array('44035008625');//44035008625 39657447492
$goodid = array('43187041028');//43187041028  18712713115
$changeval = '625新品 零点首发 抢先收藏';

define("DIRPATH", dirname(__FILE__));//当前文件路劲
define("AUTODIR", dirname(dirname(__FILE__)));

require DIRPATH.'/taobao_function.php';
require DIRPATH.'/Strlen.php';

//echo '<pre>';

$newidarr = array_chunk($goodid,20);//把id拆分为20个一组
$fields = 'title,pic_url,num,num_iid,outer_id,cid,sell_point';
$eroor = array();//错误宝贝信息

use Top\schema\factory\SchemaReader;
use Top\schema\factory\SchemaWriter;
use Top\schema\value\ComplexValue;

foreach($newidarr as $k => $v){
    $numids = implode(',', $v);
    $goodinfolist = get_goods_cid($fields,$numids,$session);//获取宝贝基本信息
    if(isset($goodinfolist['items_seller_list_get_response']) && isset($goodinfolist['items_seller_list_get_response']['items'])){
        $goodinfo = $goodinfolist['items_seller_list_get_response']['items']['item'];
        foreach($goodinfo as $onk =>$onev){//一个宝贝处理
            $title_cid = $onev['cid'];
            $numid = $onev['num_iid'];

            if ($shoptype == 'C') {  //C店
                $goods_rule = get_cshop_goodrule($session, $title_cid, $numid, 'subTitle');
                $rulefile = 'item_increment_update_schema_get_response';
                $updatefile = 'update_rules';
            }elseif ($shoptype == 'B') {  //天猫店铺
                $goods_rule = get_good_rule($numid, $session,'sell_points');
                $rulefile = 'tmall_item_increment_update_schema_get_response';
                $updatefile = 'update_item_result';
            }

            if (isset($goods_rule['error_response'])){
                $eroor[$numid]['userid'] = $userid;
                $eroor[$numid]['num_iid'] = $numid;
                $eroor[$numid]['reason'] = isset($goods_rule['error_response']['sub_msg']) ? $goods_rule['error_response']['sub_msg'] : $goods_rule['error_response']['msg'];
                continue;
            }

            if(!isset($goods_rule[$rulefile][$updatefile])){
                $eroor[$numid]['userid'] = $userid;
                $eroor[$numid]['num_iid'] = $numid;
                $eroor[$numid]['reason'] = '获取宝贝卖点规则错误';
                continue;
            }
            $one_rule = $goods_rule[$rulefile][$updatefile];
          //  echo "<textarea>".$one_rule."</textarea>";
            //print_r($one_rule);
            $schemaReader = new SchemaReader;
            $xml_list = $schemaReader->readXmlForList($one_rule);//读取规则变成xml数组
            // print_r($xml_list);
            // exit;
            if(empty($xml_list)){
                $eroor[$numid]['userid'] = $userid;
                $eroor[$numid]['num_iid'] = $numid;
                $eroor[$numid]['reason'] = '读取标题编辑规则错误';
                continue;
            }

            if ($shoptype == 'C'){//淘宝
                $newxmllist =  hand_taobao_point($xml_list);
            }else{//天猫
                $newxmllist =  hand_tmall_point($xml_list);
                // print_r($newxmllist);
                // exit;
                if($newxmllist == false){
                    $eroor[$numid]['userid'] = $userid;
                    $eroor[$numid]['num_iid'] = $numid;
                    $eroor[$numid]['reason'] = '最多5个卖点短语,每个卖点短语最多6个字,总字数不超过20个字';
                    continue;
                }
            }
            hand_point_res($newxmllist,$numid);//api操作结果
        }
    }else{
        echo json_encode(array('status'=>600,'info'=>'获取商品信息失败'.implode(',',$goodinfolist['error_response'])));
        exit;
    }
}

// if(count($eroor) > 0){
//     require DIRPATH.'/mysqlClass.php';
//     $db = new MysqlDB();
//     $sql = " INSERT INTO `bat_modifyerror`(`userid`,`opid`,`pid`,`baterr`,`username`) VALUES ";
//     $time = time();
//     $usernick = mysql_real_escape_string($usernick); 
//     foreach($eroor as $erk => $erv){
//         $reson = mysql_real_escape_string($erv['reason']);
//         $insertsql = $sql."($userid,'$time',$erk,'".$reson."','$usernick')";
//         $db->save($insertsql);
//     }
//     $db->close();
//     echo json_encode(array('state'=>800,'info'=>count($eroor).'个宝贝修改失败,请查看修改历史记录'));
// }else{
//   echo json_encode(array('state'=>800,'info'=>'修改成功'));
// }
exit;

//淘宝卖点修改
function hand_taobao_point($xml_list){
    global $changeval;
    foreach ($xml_list as $key => $v_val) {
        $file_id = $v_val->getId();
        if ($file_id == 'update_fields') {//跟新字段
            $v_val->setValueWithDefault();//设置value值等于defaultvalue
            continue;
        }
        if ($file_id == 'subTitle') {//有需要修改的卖点信息
            $type = $v_val->getType();
            if ($type == 'input') {
                $v_val->setValue($changeval);//设置为最新的值
            }
        }
    }
    return $xml_list;
}
//淘宝卖点修改
function hand_tmall_point($xml_list){
    global $changeval;

    $changearr = !empty($changeval) ? explode(' ',$changeval) : array();
    $newxmllist = array();
    $codelen = 0;
    //print_r($xml_list);
    foreach($xml_list as $key =>$val){
        $type = $val->getType();//获取当前标签的类型
        $id = $val->getId();
        $name = $val->getName();
        if($type == 'label' && $id == 'infos'){//label作为提示标签，不用传到淘宝接口，自动忽略
            continue;
        }

        if($type == 'multiCheck' && $id == 'update_fields'){//MultiCheckField
            $val->setValues($val->getDefaultValues());
            $val->setValue($val->getDefaultValue());
        }else if($type == 'complex' && $id == 'sell_points'){//复杂数据结构-描述操作
            
            $defalutcomvlue = $val->getDefaultComplexValue();//获取当前描述的默认值
            $defaultval = array();
            if(!empty($defalutcomvlue)){
                $defaultval = $defalutcomvlue->getValues();//获取所有的值
            }else{
                $val->setDefaultComplexValue(new ComplexValue());//新增结构
                $defalutcomvlue = $val->getDefaultComplexValue();//获取当前描述的默认值
            }
            $fields = $val->getFieldList();//获取支持的file列表
    
            //遍历filed
            foreach($fields as $filekey => $fileval){
                $keynumber = substr($filekey,strlen($dfkey)-1);
                if(empty($defaultval) || !isset($defaultval[$filekey])){//如果为空或者没有
                    $onefiled = $fileval;
                    $onefiled->emptyRules();//清空rules
                    $onefiled->setValue($changearr[$keynumber]);
                    $codelen += mb_strlen($changearr[$keynumber],'UTF-8');//总长度
                    $defalutcomvlue->put($onefiled);//新增加一个值
                }else{
                    $onevals = $defaultval[$filekey];
                    if(isset($changearr[$keynumber])){
                        $newval = mb_strlen($changearr[$keynumber],'UTF-8') > 6 ? mb_substr($changearr[$keynumber],0,6,'UTF-8') : $changearr[$keynumber];
                    }else{
                        $newval = '';//清空
                    }
                    $codelen += mb_strlen($newval,'UTF-8');//总长度
                    $onevals->setValue($newval);//设置最新修改的值
                }
            }
            $val->setValueWithDefault();//给complevalue赋值成默认的defaultcomplevalue
        }
        $newxmllist[] = $val;
    }

    if($codelen > 20 ){
        return false;
    }
    return $newxmllist;
}

function hand_point_res($newxmllist,$numid){
    global $shoptype;
    global $error;//错误信息
    global $userid;
    global $session;
    $schemaWriter = new SchemaWriter;
    $new_rule = $schemaWriter->writeParamXml($newxmllist);
    if ($shoptype == 'C') {//C店
        $writer = write_cshop_good_desc($numid, $session, $new_rule);
        $result_filed = 'item_schema_increment_update_response';
    } else {
        $result_filed = 'tmall_item_schema_increment_update_response';
        $writer = write_good_desc($numid, $session, $new_rule);
    }
    print_r($writer);
    exit;
    if (!isset($writer[$result_filed])) {  //修改失败
        $eroor[$numid]['userid'] = $userid;
        $eroor[$numid]['num_iid'] = $numid;
        $eroor[$numid]['reason'] = isset($writer['error_response']['sub_msg']) ? $writer['error_response']['sub_msg'] : $writer['error_response']['msg'];
    }
}


//自动载入文件
function __autoload($className)
{
    $className = str_replace('\\','/',$className);
    $classPath = DIRPATH."/" .$className . '.php';
    if (file_exists($classPath)) {
        require_once($classPath);
    } else {
        echo 'class file' . $classPath . 'not found!';
    }
}