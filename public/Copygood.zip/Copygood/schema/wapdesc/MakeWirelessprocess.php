<?php

/**
 * 功能：全店手机详情制作
 * @package  
 * @author  Li
 */
define("DIRPATH",dirname(__DIR__));//定义项目跟路劲
define('LOGDIR',DIRPATH.'/wapdesc/log/');

set_time_limit(0);//防止超时

$redis = new Redis();
$redis->connect('127.0.0.1',6379);//实例化
$redis->auth('foobar');

$len = $redis->llen('web_wap_desc_list');//获取队列长度
if($len > 0){
	while(true){//需要一直执行

		$commond = 'ps -ef | grep "'.DIRPATH.'/wapdesc/OneMakeprocess.php" | grep -v grep | wc -l';
		$processnum = exec($commond);//获取开启的执行进程数量

		if($processnum > 10){//如果开启的进程大于10个，等待一会儿
			sleep(3);//停留一秒
			//echo "此刻正在停留中";
		}else{
			$getdata = $redis->rpop('web_wap_desc_list');//从尾部取出元素
			if($getdata){//正常取出值

				$filename = LOGDIR.date('Y-m-d').'_oneprocess.txt';
				$cmdstr = DIRPATH.'/wapdesc/OneMakeprocess.php '.$getdata;
				$out = popen('nohup /usr/local/php/bin/php '.$cmdstr.' >> '.$filename.' 2>&1 &', "r");//打开一个进程执行php文件
				pclose($out);//关闭进程管道
				// $rundata = json_decode($getdata,true);
				// if(is_array($rundata)){
				// 	echo "取出数据\r\n";
				// 	print_r($rundata);
				// }
			}else{//取值为空，表示数据已经全部处理完
				//echo "数据处理完\r\n";
				$redis->close();
				exit;
			}
		}
	}
}else{
	echo "没有数据关闭\r\n";
	$redis->close();
	exit;
}

// $redis = new Redis();
// $redis->connect('127.0.0.1',6379);//实例化

// $value = 'value_1';
// $redis->lpush('wirelesslist',$value);//从队列前面插入一个元素

// $value = 'value_2';
// $redis->lpush('wirelesslist',$value);//从队列前面插入一个元素

// $value = json_encode(array('a'=>1,'b'=>2));
// $redis->lpush('wirelesslist',$value);//从队列前面插入一个元素

// echo '<br>';
// $hasdata = $redis->lrange('wirelesslist',0,-1);

// print_r($hasdata);

// $len = $redis->llen('wirelesslist');//获取队列长度

// echo '<br>len:'.$len.'<br>';
// $getdata = $redis->rpop('wirelesslist');//从尾部取出元素
// echo '<br>data1:'.$getdata;
// $getdata = $redis->rpop('wirelesslist');//从尾部取出元素
// echo '<br>data2:'.$getdata;
// $getdata = $redis->rpop('wirelesslist');//从尾部取出元素
// echo '<br>data3:';
// print_r(json_decode($getdata,true));
?>