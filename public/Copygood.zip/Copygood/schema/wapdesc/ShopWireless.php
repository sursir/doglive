<?php

/**
 * 功能：全店手机详情制作
 * @package  
 * @author  Li
 */
define("DIRPATH",dirname(__DIR__));//定义项目跟路劲
define('LOGDIR',DIRPATH.'/wapdesc/log/');
$userid = isset($_POST['userid']) ? intval($_POST['userid']) : '';
$haspass = isset($_POST['haspass']) ? intval($_POST['haspass']) : 1;//过滤参数 //1过滤 2 不过滤
$itemtype = isset($_POST['itemtype']) ? trim($_POST['itemtype']) : 1;//宝贝范围 onsail  inventory
$numarr = isset($_POST['numarr']) ? $_POST['numarr'] : array();//少量制作的商品id
$goodtype = isset($_POST['goodtype']) ? trim($_POST['goodtype']) : '';//少量制作还是全店制作
$maketype = isset($_POST['maketype']) ? trim($_POST['maketype']) : '';//全图还是分离
 $returndata['code'] = 400;
if(empty($userid) || empty($maketype) || empty($goodtype)){
    $returndata['info'] = '缺少参数';
    echo json_encode($returndata);
    exit;
}

//引入必须类库
require DIRPATH.'/mysqlClass.php';
require DIRPATH.'/taobao_function.php';

//获取session信息
$hndir = 'http://121.41.168.185/huoniu/';
$session = trim(file_get_contents($hndir.'proxy_getsession.php?uid='.$userid));

if($session === -1){
	$returndata['code'] = 500;
    $returndata['info'] = '请先联系主号授权后再操作';
    echo json_encode($returndata);
    exit;
}

$shoparr = getshoptype($userid,$session);//获取店铺类型
if($shoparr !=='B' && $shoparr !=='C'){
    $returndata['info'] = '获取店铺类型失败';
    echo json_encode($returndata);
    exit;
}
$shoptype = $shoparr;

$paramsarr = array();
$paramsarr['maketype'] = $maketype;
$paramsarr['session'] = $session;
$paramsarr['userid'] = $userid;
$paramsarr['haspass'] = $haspass;//是否过滤已经制作过的宝贝
$paramsarr['shoptype'] = $shoptype;//店铺类型

$redis = new Redis();
$redis->connect('127.0.0.1',6379);//实例化
$redis->auth('foobar');
//$redis->del('wirelesslist');//删除key
//echo '<pre>';

$db = new MysqlDB(); //new MysqlDB();

if($goodtype == 'less'){//少量制作
	if(count($numarr) > 0){
		$insertsql = 'replace into make_wireless_list(numid,userid,outerid,title,makeres,picurl) values ';
		foreach($numarr as $k => $v){
			$insertsql .= "($v,$userid,'','',0,''),";
		}
		$insertsql = substr($insertsql,0,-1);
		$res = $db->save($insertsql);
		if($res > 0){
			$paramsarr['itemlist'] = implode(',',$numarr);
			$value = json_encode($paramsarr);
			$redis->lpush('web_wap_desc_list',$value);
			go_make();
			$returndata['code'] = 800;
    		$returndata['info'] = '已经开始制作,请稍后刷新查看结果';
		}else{
    		$returndata['info'] = '存入数据库失败';
		}
	}else{
    	$returndata['info'] = '缺少商品id';
	}
}else{
	//全店制作
	$field = 'num_iid';
	$npage = 1;
	$pagesize = 200;
	if($itemtype == 'onsail'){//表示制作出售中的宝贝
		$jiekou = 'taobao.items.onsale.get';
		$resfiled = 'items_onsale_get_response';
	}else{//仓库中的宝贝
		$jiekou = 'taobao.items.inventory.get';
		$resfiled = 'items_inventory_get_response';
	}

	$onepagegood = get_shop_good($session, $jiekou,$field, $npage, $pagesize);//获取第一页商品，同时获取出宝贝总数
	//api错误
	if(isset($onepagegood['error_response'])){//获取宝贝出错
	    $returndata['info'] = '获取宝贝失败'.$onepagegood['error_response']['msg'];
	}else{
		//正确搜索出宝贝
		if(isset($onepagegood[$resfiled]['items']['item'])){
			$totalnum = $onepagegood[$resfiled]['total_results'];
			if($totalnum > $pagesize){//如果店铺宝贝大于200
				$itemlist = $onepagegood[$resfiled]['items']['item'];
				foreachgooditemlist($redis,$paramsarr,$itemlist);//先加入第一页宝贝
				//需要分页全部获取出来
				$allpage = ceil($totalnum/$pagesize);
				for($start =2;$start<=$allpage;$start++){
					$onepagegood = get_shop_good($session, $jiekou,$field, $start, $pagesize);
					if(isset($onepagegood[$resfiled]['items']['item'])){//只有取出宝贝才加入队列
						$itemlist = $onepagegood[$resfiled]['items']['item'];
						foreachgooditemlist($redis,$paramsarr,$itemlist);
					}
				}
			}else{
				$itemlist = $onepagegood[$resfiled]['items']['item'];
				foreachgooditemlist($redis,$paramsarr,$itemlist);
			}
			go_make();
		    $returndata['code'] = 800;
			$returndata['info'] = '已经开始制作,请稍后刷新查看结果';
		}else{
		    $returndata['info'] = '未知错误'.implode(',',$onepagegood);
		}
	}
}
$db->close();
$redis->close();
echo json_encode($returndata);
exit;
// $data1 = $redis->lrange('wirelesslist',0,-1);//返回所有元素
// $len = $redis->llen('wirelesslist');//获取队列长度

function go_make(){
	$commond = 'ps -ef | grep "'.DIRPATH.'/wapdesc/MakeWirelessprocess.php" | grep -v grep | wc -l';
	$processnum = exec($commond);//判断分发进程文件是否启动
	if($processnum == 0){//表示没启动
		$filename = LOGDIR.date('Y-m-d').'_stratpro.txt';
		$cmdstr = DIRPATH.'/wapdesc/MakeWirelessprocess.php';
		$out = popen('nohup /usr/local/php/bin/php '.$cmdstr.' >> '.$filename.' 2>&1 &', "r");//打开一个进程执行php文件
		pclose($out);//关闭进程管道
	}
}


//遍历宝贝。加入到队列中
function foreachgooditemlist(&$redis,&$paramsarr,$gooditem){
	if(count($gooditem) > 0){
		$onelist = array();//一个队列的数据
		$onelistparams = $paramsarr;
		$splitgooditem = array_chunk($gooditem, 20);//已20个为一组拆分
		foreach($splitgooditem as $onelistval){
			$onelist = array();//清空数组
			foreach($onelistval as $val){
				$onelist[] = $val['num_iid'];
			}
			if(!empty($onelist)){
				$onelistparams['itemlist'] = implode(',',$onelist);
				$value = json_encode($onelistparams);
				$redis->lpush('web_wap_desc_list',$value);
			}
		}
	}
}
	

?>