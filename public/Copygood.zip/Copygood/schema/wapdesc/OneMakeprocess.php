<?php
/**
 * 功能：一个手机详情制作
 * @package  
 * @author  Li
 */

//参数样例
// Array
// (
//     [maketype] => 2
//     [session] => 6100b089f01fc9261fc73fh62b7eb047064ab3b98034b0c2471974611
//     [userid] => 687179184
//     [haspass] => 2
//     [shoptype] => C
//     [itemlist] => 524132433381
// )

    
    $g_argv = array();//参数数组
    for($i=1;$i<count($argv);$i++){
        $param = $argv[$i];
        $paramarr = explode(':',$param);
        $g_argv[$paramarr[0]] = $paramarr[1];
    }

    define("DIRPATH",dirname(__DIR__));//定义项目跟路劲
    define('LOGDIR',DIRPATH.'/wapdesc/log/');

    if(!isset($g_argv['userid'])){
        echo "缺少userid\r\n";
        print_r($g_argv);
        echo "原内容\r\n";
        print_r($argv);
        exit;
    }

    $userid = isset($g_argv['userid']) ? intval($g_argv['userid']) : die('缺少userid');

     $params = array(
        'maketype' => $g_argv['maketype'],//制作模式 1,全图模式 2,图文分离模式
        'width' => 620,//图片宽度
        'cuttype' => 1,//是否裁剪
        'height' => 960,//图片高度
        'level' => 100//图片质量
        );
    
    $numidstr = isset($g_argv['itemlist']) ? $g_argv['itemlist'] : die($userid.'-缺少商品id');
    $numidarr = explode(',',$numidstr);//商品数组

    //引入必须类库
    require DIRPATH.'/mysqlClass.php';
    require DIRPATH.'/taobao_function.php';
    require DIRPATH.'/uploadimg/TopClient.php';
    require DIRPATH.'/uploadimg/PictureUploadRequest.php';
    require DIRPATH.'/uploadimg/PictureGetRequest.php';

    $errlog = LOGDIR.date('Y-m-d').'_errlog.txt';

    $session = $g_argv['session'];

	use Top\schema\factory\SchemaReader;
	use Top\schema\factory\SchemaWriter;

    $shoptype = $g_argv['shoptype'];//店铺类型

    //判断图片分类
    $catimgtitle = '火牛手机详情(勿删)';
    //$catimgtitle = 'xxx';
    //检测用户是否有手机详情的图片分类
    $catarr = get_user_img_type($session, $catimgtitle);
   	if(!empty($catarr['picture_category_get_response']['picture_categories'])){
		$catid = $catarr['picture_category_get_response']['picture_categories']['picture_category'];//返回分类id
	}else{
		if(isset($catarr['error_response'])){//如果有错误信息
			if(isset($catarr['error_response']['msg'])){
				$info = $userid.'查询图片分类未成功'.$catarr['error_response']['msg'];
			}else{
				$info = $userid.'-查询图片分类未成功'.$catarr['error_response']['code'];
			}
            write_log_new($errlog,$info);
	       exit;
		}
	}

    $pid = 0;//图片类目id
    if(!empty($catid) ){//已有图片分类
        $pid = $catid[0]['picture_category_id'];
    }else{
        //没有需要创建火牛素材库
        $addres = add_user_img_cat($session,$catimgtitle);//添加分类id
       	if(isset($addres['error_response'])){//如果有错误信息
			if(isset($catarr['error_response']['msg'])){
                $info = $userid.'创建图片分类未成功'.$catarr['error_response']['msg'];
            }else{
                $info = $userid.'-创建图片分类未成功'.$catarr['error_response']['code'];
            }
            write_log_new($errlog,$info);
            exit;
		}
		if(!empty($addres['picture_category_add_response']['picture_category']['picture_category_id'])){
        	$pid = $addres['picture_category_add_response']['picture_category']['picture_category_id'];
        }
    }
    if($pid == 0){
        write_log_new($errlog,$userid.'-创建图片分类未成功');
        exit;
    }

    if($shoptype != 'B' && $shoptype != 'C'){
        write_log_new($errlog,$userid.'-未知店铺类型');
        exit;
    }

    $db = new MysqlDB();//实例化数据库

foreach($numidarr as $numid){
        $getfields = 'desc,desc_modules,wireless_desc,title,num_iid,pic_url,cid,outer_id';
        $goodinfo = search_one_good($session, $getfields,$numid);//获取宝贝详细信息

        if(isset($goodinfo['error_response'])){
            $info = $userid.'获取宝贝信息('.$numid.')失败'.array_to_string_new($goodinfo['error_response']);
            write_log_new($errlog, $info);
           continue;
        }

        if(!isset($goodinfo['item_seller_get_response']['item'])){
            $info = $userid.'获取宝贝信息('.$numid.')失败'.array_to_string_new($goodinfo);
            write_log_new($errlog, $info);
            continue;
        }
        $goodres = $goodinfo['item_seller_get_response']['item'];
        $goodcid = $goodres['cid'];

        //生成无线详情---start
        $olddesc = $goodres['desc'];//取出描述
        //如果设置了过滤已经制作的宝贝
        if($g_argv['haspass'] == 1 &&  isset($goodres['wireless_desc']) && !empty($goodres['wireless_desc'])){
            continue;
        }

        $newdesc = del_some_tphtml($olddesc);//去掉一些同行模版
        $allimgsize = 0;//总图片大小
        $allstrlen = 0;//总字符长度
        if($params['maketype'] == 1){//全图模式

            //写入html文件
            $htmlcontent = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd"><html><head><meta http-equiv="Content-Type" Content="text/html;" charset="utf-8"></head><body style="background:#ffffff;width:750px">';
            $htmlcontent .=  $newdesc;
            $htmlcontent .= '</body></html>';
            $htmlfilename = $userid.'_'.$numid;//保存的html文件
            $htmlfilepath = DIRPATH.'/wapdesc/wirelesshtml/'.$htmlfilename.'.html';
            file_put_contents($htmlfilepath,  $htmlcontent);

            //$servername = $_SERVER['HTTP_HOST'];//当前服务器的域名或者ip
            //把详情生成图片
           // $url = 'http://121.199.162.194/hnitem/hnitempc/wirelesshtml/'.$htmlfilename.'.html';
            //$url = 'http://'.$servername.'/hnitem/hnitempc/wirelesshtml/'.$htmlfilename.'.html';
            $url = './wirelesshtml/'.$htmlfilename.'.html';
            $path = DIRPATH.'/wapdesc/wirelessimg/'.$htmlfilename.'.jpg';// jpg 比 png的图片尺寸更小
            
            $commond = "phantomjs ".DIRPATH.'/wapdesc/wireless.js '.$url.' '.$path;
            $makeimgcomplate = exec($commond,$out,$status);

            @unlink($htmlfilepath);//删除生成的静态html文件

            if(stripos($makeimgcomplate,'finish') < 0 || !file_exists($path)){
                add_make_list($db,$userid,$goodres,2,'生成全图失败'.implode(',',$out));//添加制作结果记录
                $info = 'uid:'.$userid.':numid:'.$numid.'生成全图失败';
                write_log_new($errlog, $info);
                continue;
            }

            //对图片进行处理
            $imagick = new Imagick($path);
            $sizeinfo = $imagick->getimagesize();//获取图片大小
            $height = $imagick->getImageHeight();//获取图片高度
            $width = $imagick->getImageWidth();//获取图片宽度
            //$imginfo =  $imagick->getImagePage();//获取图片信息
            //宽度压缩
            $newheight = intval($params['width']*$height/$width);//新的高度 
            $imagick->thumbnailImage ( $params['width'], $newheight, true );//将图片压缩到指定宽度
            $oldimgnewver = DIRPATH.'/wapdesc/wirelessimg/'.$htmlfilename.'_new.jpg';
            $imagick->writeImage($oldimgnewver);//生成新的指定宽度的图片
            @unlink($path);//删除老的图片

            //质量压缩
            $imagick = new Imagick($oldimgnewver);
            //获取图片最大压缩比 * 我们希望的压缩率 = 实际图片质量
            $compression = intval($imagick->getImageCompressionQuality() * ($params['level']/100));
            if($compression == 0){
                $compression = 70 ;//默认压缩到70%
            }

            $imagick->setImageCompression(Imagick::COMPRESSION_JPEG);//以jpeg的形式来压缩
            //echo '图片压缩比例：'. $compression."<br>";
            $imagick->setImageCompressionQuality($compression);//质量压缩 60 -100
            $imagick->stripImage();//去掉图片的一些无用扩展信息
            $oldimgnewver2 = DIRPATH.'/wapdesc/wirelessimg/'.$htmlfilename.'_new2.jpg';
            $imagick->writeImage($oldimgnewver2);//生成新的质量的图片
            @unlink($oldimgnewver);//删除老的图片

            $height = $imagick->getImageHeight();//获取新的图片高度
            $path = $oldimgnewver2;//用压缩过的图片来操作

            $sucessupload = array();//上传成功的图片
            
            if($height > $params['height']){//如果高度大于指定的高度。需要拆分图片
                $imagenum = ceil($height/$params['height']);
                $savepath = DIRPATH.'/wapdesc/wirelessimg/';//保存路劲
                $needupload = array();//需要上传的图片
                //拆分图片
                for($i=1;$i<=$imagenum;$i++){
                    $imagick = new Imagick($path);
                    $cutheight = ($i-1)*$params['height'];
                    $imagick->cropImage($params['width'], $params['height'], 0, $cutheight);//生成图片的 宽，高， 截取位置 x y
                   // $newsavepath  = $savepath.$userid.'_'.$cutheight.'_'.$i.'.jpg';
                    $newsavepath  = $savepath.$userid.'_'.$numid.'_'.$cutheight.'_'.$i.'.jpg';
                    $imagick->writeImage($newsavepath);
                    $needupload[]  = $newsavepath;
                }
                //上传图片
                foreach($needupload as $key=>$val){
                    $title = $userid.'_'.strtotime('now').'_'.$key;
                    $uploadres = uplaod_tp_img($session,'@'.$val,$title,$pid);
                    @unlink($val);
                    if(isset($uploadres['picture']) && isset($uploadres['picture']['picture_path'])){
                        $allimgsize += $uploadres['picture']['sizes'];
                        $newmb = intval(($allimgsize/1024/1024)*10);//乘10来比较。避免精度问题
                        if($newmb >= 25){
                            break;
                        }
                        $sucessupload[] =  array('content'=>$uploadres['picture']['picture_path'],'type'=>'image');//记录上传成功的图片路劲
                    }else{
                        print_r($uploadres);
                        //图片上传失败
                        add_make_list($db,$userid,$goodres,2,'制作过程错误,图片上传失败');//添加制作结果记录
                        $info = 'uid:'.$userid.' numid:'.$numid.'制作过程错误,图片上传失败';
                        write_log_new($errlog, $info);
                    }
                }
            }else{//直接操作原图即可
                $title = $userid.'_'.strtotime('now').'_0';
                $uploadres = uplaod_tp_img($session,'@'.$path,$title,$pid);
                @unlink($path);//删除原图片
                if(isset($uploadres['picture']) && isset($uploadres['picture']['picture_path'])){
                    $sucessupload[] =  array('content'=>$uploadres['picture']['picture_path'],'type'=>'image');//记录上传成功的图片路劲
                }else{
                    print_r($uploadres);
                    //图片上传失败
                    add_make_list($db,$userid,$goodres,2,'制作过程错误,图片上传失败');//添加制作结果记录
                    $info = 'uid:'.$userid.' numid:'.$numid.'制作过程错误,图片上传失败';
                    write_log_new($errlog, $info);
                    continue;
                }
            }
           
            $contentarr = $sucessupload;

        }else{//图文分离

            $descarr = split_pc_desc($newdesc);//把详情拆分成数组

            if(empty($descarr)){
                add_make_list($db,$userid,$goodres,2,'图文分离拆分详情失败');//添加制作结果记录
                $info = 'uid:'.$userid.' numid:'.$numid.'图文分离拆分详情失败';
                write_log_new($errlog, $info);
                continue;
            }

            $newdescarr = array();//过滤后的无线手机详情
            $passimgwidth = 480;//过滤宽度小于480的照片

            //过滤图片
            //计算字符串，图片大小
            foreach($descarr as $key => $val){

                if($val['type'] == 'image'){//说明是图片
                    $imageinfo = array();
                    $imageinfo = @getimagesize($val['content']);
                    if(empty($imageinfo)){
                        $info = $userid.'==='.$numid.'获取图片信息失败'.$val['content'];
                         write_log_new($errlog, $info);
                        continue;
                    }

                    //图片宽度只能在480-620之间,高度必须在960以下
                    if($imageinfo[0] < 480 ){//如果图片宽度小于480 直接过滤
                        continue;
                    }

                    //对图片进行处理
                    $imagick = new Imagick($val['content']);
                    $sizeinfo = $imagick->getimagesize();//获取图片大小
                    $height = $imagick->getImageHeight();//获取图片高度
                    $width = $imagick->getImageWidth();//获取图片宽度
                    //$imginfo =  $imagick->getImagePage();//获取图片信息
                    $newsavepath = DIRPATH.'/wapdesc/wirelessimg/';
                    if($width > 620 || $height > $params['height']){
                        //支持裁剪
                        if($params['cuttype'] == 1){
                            $newimgname =  $userid.'_'.$numid.'_'.$key;
                            $savepath = $newsavepath.$newimgname.'.jpg';//下载后保存的图片地址
                            file_put_contents($savepath, file_get_contents($val['content']));//下载图片到本地

                            $newsavepath2  = $newsavepath.$newimgname.'_new2.jpg';//最终生成的图片地址
                            if($width > 620){//宽度不合法
                                $newwidth = $params['width'];//指定宽度
                                $imagick->thumbnailImage ($newwidth,$height, true );//将图片压缩到指定宽度
                                $oldimgnewver = $newsavepath.$newimgname.'_new.jpg';
                                $imagick->writeImage($oldimgnewver);//生成新的指定宽度的图片
                                //unlink($savepath);//删除老的图片
                                $imagick = new Imagick($oldimgnewver);
                                $height = $imagick->getImageHeight();//重新获取图片高度
                                $width = $imagick->getImageWidth();//重新获取图片高度
                                $newsavepath2  = $newsavepath.$newimgname.'_new2.jpg';
                                if($height > $params['height']){//如果缩放过后高度大于指定高度 需要进行截取
                                    $cutheight = $params['height'];
                                    $imagick->cropImage( $width, $params['height'], 0, 0);//生成图片的 宽，高， 截取位置 x y
                                }
                                @unlink($oldimgnewver);//删除老的图片
                            }else if($height > $params['height']){//高度大于指定高度
                                $imagick = new Imagick($savepath);//直接裁剪
                                $imagick->cropImage( $width, $params['height'], 0, 0);//生成图片的 宽，高， 截取位置 x y
                            }
                            if($params['level'] >= 60 && $params['level'] < 80){//进行压缩
                                //获取图片最大压缩比 * 我们希望的压缩率 = 实际图片质量
                                $compression = intval($imagick->getImageCompressionQuality() * ($params['level']/100));
                                if($compression == 0){
                                    $compression = 70 ;//默认压缩到70%
                                }
                                $imagick->setImageCompression(Imagick::COMPRESSION_JPEG);//以jpeg的形式来压缩
                                $imagick->setImageCompressionQuality($compression);//质量压缩 60 -100
                            }
                            $imagick->stripImage();//去掉图片的一些无用扩展信息
                        }else{
                            //不支持裁剪的 直接过滤
                            continue;
                        }
                        $imagick->writeImage($newsavepath2);
                        $title = $newimgname;
                        $uploadres = uplaod_tp_img($session,'@'.$newsavepath2,$title,$pid);
                        @unlink($newsavepath2);
                        @unlink($savepath);
                        if(isset($uploadres['picture']) && isset($uploadres['picture']['picture_path'])){
                             $allimgsize += $uploadres['picture']['sizes'];
                            $newmb = intval(($allimgsize/1024/1024)*10);//乘10来比较。避免精度问题
                            if($newmb >= 25){
                                break;
                            }
                            $newdescarr[] = array('content'=>$uploadres['picture']['picture_path'],'type'=>'image');
                            continue;
                        }else{

                            $info = 'uid:'.$userid.' numid:'.$numid.'制作过程错误,图片上传失败';
                            echo $info."\r\n";
                            print_r($uploadres);
                            //图片上传失败
                            add_make_list($db,$userid,$goodres,2,'制作过程错误,图片上传失败');//添加制作结果记录
                            write_log_new($errlog, $info);
                        }
                    } else {
                        //宽度高度都合法
                        //如果图片质量在60-80之前 就对图片进行压缩
                        if($params['level'] >= 60 && $params['level'] < 80){

                            $newimgname =  $userid.'_'.$numid.'_'.$key;
                            $savepath = $newsavepath.$newimgname.'.jpg';//下载后保存的图片地址
                            file_put_contents($savepath, file_get_contents($val['content']));//下载图片到本地
                            $newsavepath2  = $newsavepath.$newimgname.'_new2.jpg';//最终生成的图片地址
                            $imagick = new Imagick($savepath);
                            //获取图片最大压缩比 * 我们希望的压缩率 = 实际图片质量
                            $compression = intval($imagick->getImageCompressionQuality() * ($params['level']/100));
                            if($compression == 0){
                                $compression = 70 ;//默认压缩到70%
                            }
                            $imagick->setImageCompression(Imagick::COMPRESSION_JPEG);//以jpeg的形式来压缩
                            $imagick->setImageCompressionQuality($compression);//质量压缩 60 -100
                            $imagick->stripImage();//去掉图片的一些无用扩展信息
                            $imagick->writeImage($newsavepath2);
                            $title = $newimgname;
                            $uploadres = uplaod_tp_img($session,'@'.$newsavepath2,$title,$pid);
                            @unlink($newsavepath2);
                            @unlink($savepath);
                            if(isset($uploadres['picture']) && isset($uploadres['picture']['picture_path'])){
                                $allimgsize += $uploadres['picture']['sizes'];
                                $newmb = intval(($allimgsize/1024/1024)*10);//乘10来比较。避免精度问题
                                if($newmb >= 25){
                                    break;
                                }
                                $newdescarr[] = array('content'=>$uploadres['picture']['picture_path'],'type'=>'image');
                                continue;
                            }else{
                                 $info = 'uid:'.$userid.' numid:'.$numid.'制作过程错误,图片上传失败';
                                echo $info."\r\n";
                                print_r($uploadres);
                                //图片上传失败
                                add_make_list($db,$userid,$goodres,2,'制作过程错误,图片上传失败');//添加制作结果记录
                                $db->close();
                               
                                write_log_new($errlog, $info);
                                continue;
                            }
                        }
                        $allimgsize +=  $sizeinfo;//图片大小
                        $newmb = intval(($allimgsize/1024/1024)*10);//乘10来比较。避免精度问题
                         if($newmb >= 25){
                            break;
                        }
                    }

                    //到这里说明图片是在480-620 之间 高度是小于960 的这个是符合条件的
                    $newdescarr[] = $val;
                }else{
                    $newdescarr[] = $val;
                    $allstrlen += strlen($val['content']);
                }
            }
            $contentarr = $newdescarr;
        }

        if(empty( $contentarr )){
            add_make_list($db,$userid,$goodres,2,'制作过程错误,未能生成手机详情');//添加制作结果记录
            $info = 'uid:'.$userid.' numid:'.$numid.'制作过程错误,未能生成手机详情';
            write_log_new($errlog, $info);
            continue;
        }

        //获取手机端描述内容增量修改规则
        if($shoptype == 'C'){//C店

            //$updateid = 'wl_description';
            //$updatecontent = 'wl_description_content';
            $updateid = 'descForMobile';//descForPC
            $updatecontent = 'content';

            //获取手机端描述内容增量修改规则
            $goodrule = get_cshop_goodrule($session,$goodcid,$numid,$updateid);
            if(!isset($goodrule['item_increment_update_schema_get_response'])){
                $returndata['code'] = 500;
                $returndata['info'] = '获取宝贝编辑规则出错'.array_to_string_new( $goodrule);
                add_make_list($db,$userid,$goodres,2,$returndata['info']);//添加制作结果记录
                $db->close();
                echo json_encode($returndata);
                exit;
            }
            $onerule = $goodrule['item_increment_update_schema_get_response']['update_rules'];
        }else{
            $updateid = 'wap_desc';
            $updatecontent = 'wap_desc_content';
            $goodrule = get_good_rule($numid,$session,$updateid);
            if(!isset($goodrule['tmall_item_increment_update_schema_get_response'])){
                $returndata['code'] = 500;
                $returndata['info'] = '获取宝贝编辑规则出错'.array_to_string_new( $goodrule);
                add_make_list($db,$userid,$goodres,2,$returndata['info']);//添加制作结果记录
                $db->close();
                echo json_encode($returndata);
                exit;
            }
            $onerule = $goodrule['tmall_item_increment_update_schema_get_response']['update_item_result'];
        }

        //读取xml
        $schemaReader = new SchemaReader();
        $list = $schemaReader->readXmlForList($onerule);//读取规则变成xml数组
       
        $wirelesslist = array();
        $update_fields = array();//跟新字段
        $wl_description = array();//商品手机端详情

       foreach($list as $ky =>$vl){
            $id = $vl->getId();
            if($id == 'update_fields'){
                $update_fields = $vl;
            }else if($id == $updateid){//详情
                $wl_description = $vl;
            }
        }
      
        $update_fields->setValueWithDefault();//设置默认跟新字段

        $defaulevalue = $wl_description->getDefaultComplexValue();//判断之前是否有操作过手机详情 ComplexField
        $fieldlist = $wl_description->getFieldList();//获取支持修改的字段
        $changefiled = $fieldlist[$updatecontent];//从filedlist中获取wl_description_content 包含 type content
        $filetype = $changefiled->getType();//获取当前修改的标签类型

        if($defaulevalue){//已经有手机端操作过的宝贝(可能是音频，摘要，内容)
           
            //获取所有设置过的默认值 判断是否有无wl_description_content
            $hassetvalue = $wl_description->getDefaultComplexValue()->getValues();

            if(isset($hassetvalue['wl_description_content'])){//之前已经发布过无线详情描述

                $defaultcontent = $hassetvalue['wl_description_content'];//取出content字段 MultiComplexField 
                
                if($defaultcontent->getType() == 'multiComplex'){
                    $contentlist = $defaultcontent->getComplexValues();//之前老的手机详情
                    //$defaultcontent->emptyComplexValues();//清空老的值
                    //生成新的值
                    $values = make_wireless_content($contentarr);
                    $defaultcontent->setComplexValues( $values);//设置content的最新值-直接把老的覆盖了
                }

            }else{//未发布 需要新增 wl_description_content 但是有其他手机详情信息（摘要，音频等）
                if($filetype == 'multiComplex'){//标签类型
                    $values = make_wireless_content($contentarr);
                    $changefiled->emptyFied();//清空fileds
                    $changefiled->setName('');//清空name
                    $changefiled->setComplexValues($values);
                    $defaulevalue->put($changefiled);//直接新增一项 wl_description_content
                }
            }
            $wl_description->setValueWithDefault();//设置vlaue值为default里面的值
        }else{
            if($filetype == 'multiComplex'){//标签类型
                //待修改的内容
                $values = make_wireless_content($contentarr);
                $changefiled->emptyFied();//清空fileds
                $changefiled->setName('');//清空name
                $changefiled->setComplexValues($values);

                //这里进行增加手机详情操作
                $value1 = new \Top\schema\value\ComplexValue();//实例化一个详情对象
                $value1->put($changefiled);
                $wl_description->setComplexValue($value1);//设置最外层的complexValue
            }
        }

        $wirelesslist[] = $update_fields;
        $wirelesslist[] = $wl_description;
      
        $schemaWriter = new SchemaWriter();
        $newrule = $schemaWriter->writeParamXml($wirelesslist);
        
         if($shoptype == 'C'){//C店
            $writeres = write_cshop_good_desc($numid,$session,$newrule);
            $resultfiled ='item_schema_increment_update_response';
        }else{
            $resultfiled ='tmall_item_schema_increment_update_response';
            $writeres = write_good_desc($numid,$session,$newrule);
        }

        //制作结果
        if(isset($writeres[$resultfiled])){//制作成功
            add_make_list($db,$userid,$goodres,1);//添加制作结果记录(1表示成功)
            //write_log_new($errlog, $userid.'--'.$numid.'--succss');

        }else{
            $info= isset($writeres['error_response']) ? array_to_string_new($writeres['error_response']) : array_to_string_new($writeres);
            add_make_list($db,$userid,$goodres,2,$info);//添加制作结果记录
            $info = $userid.'numid:'.$numid.'---'.$info;
            write_log_new($errlog, $info);
        }

}

$db->close();
exit;

//自动载入文件
function __autoload($class) {   
    $class = DIRPATH.'/' . str_replace('\\', '/', $class).'.php';
    //echo $class."<br>";
    require_once($class);
}

//去除一些模版代码
function del_some_tphtml($olddesc){
    
    $head1 = "<a name=\"hn_(\d){1,}_start\">(.*)<\/a>";
    $end1 = "<a name=\"hn_(\d){1,}_end\">(.*)<\/a>";

    //去除火牛模版
    if(preg_match("/$head1/",$olddesc) > 0){
        $newdesc = preg_replace("/({$head1})(.*)({$end1})/Uis", '', $olddesc);
        //echo "<textarea >". $newdesc."</textarea>";
        $olddesc = !empty($newdesc) ? $newdesc : $olddesc;
    }

    $head2 = "<a name=\"hlg_list_(.*)_start\">(.*)<\/a>";
    $end2 = "<a name=\"hlg_list_(.*)_end\">(.*)<\/a>";
    //取出欢乐逛模版
    if(preg_match("/$head2/",$olddesc) > 0){
        $newdesc = preg_replace("/({$head2})(.*)({$end2})/Uis", '', $olddesc);
       // echo "<textarea >". $newdesc."</textarea>";
        $olddesc = !empty($newdesc) ? $newdesc : $olddesc;

    }
    //超级店长
    //<img src="http://gd4.alicdn.com/imgextra/i4/T2s4moXH8XXXXXXXXX-350475995.png?p=recommend_v2_4180937_start_top_1">
    //<img src="http://gd4.alicdn.com/imgextra/i4/T2s4moXH8XXXXXXXXX-350475995.png?p=recommend_v2_4180937_end_top_1">
    $head3 = "<img src=\"(.*)p=recommend(.*)_start_top_1\">";
    $end3 = "<img src=\"(.*)p=recommend(.*)_end_top_1\">";
    if(preg_match("/$head3/",$olddesc) > 0){
        $newdesc = preg_replace("/({$head3})(.*)({$end3})/Uis", '', $olddesc);
       // echo "<textarea >". $newdesc."</textarea>";
        $olddesc = !empty($newdesc) ? $newdesc : $olddesc;
    }

    //去除火牛促销满就送
    $head4 = '(<a name=\"hncx_mjs_(.*)_start\">(.*)<\/a>)';
    $end4 = '<a name=\"hncx_mjs_(.*)_end\">(.*)<\/a>';
    if(preg_match("/$head4/",$olddesc) > 0){//正确替换过后内容为空
        $newdesc = preg_replace("/({$head4})(.*)({$end4})/Uis", '', $olddesc);
        $olddesc = !empty($newdesc) ? $newdesc : $olddesc;
    }
     //去除火牛网页满就送
    $head6 = '(<a name=\"hn_mjs_(.*)_start\">(.*)<\/a>)';
    $end6 = '<a name=\"hn_mjs_(.*)_end\">(.*)<\/a>';
    if(preg_match("/$head6/",$olddesc) > 0){//正确替换过后内容为空
        $newdesc = preg_replace("/({$head6})(.*)({$end6})/Uis", '', $olddesc);
        $olddesc = !empty($newdesc) ? $newdesc : $olddesc;
    }

    //去除欢乐逛满就送
    $head5 = "<a name=\"hlg_promo_desc_(.*)_start\">(.*)<\/a>";
    $end5 = "<a name=\"hlg_promo_desc_(.*)_end\">(.*)<\/a>";
    if(preg_match("/$head5/",$olddesc) > 0){
        $newdesc = preg_replace("/({$head5})(.*)({$end5})/Uis", '', $olddesc);
        $olddesc = !empty($newdesc) ? $newdesc : $olddesc;
    }

    return $olddesc;
}

/**
* 制作一个手机详情内容
* @param $contentarr 添加的内容 array('content'=>'','type'=>text|image)
* @return $obj 修改好的对象
*/

function make_wireless_content($contentarr){

    $values = array();//所有手机详情
    global $shoptype;
    foreach($contentarr as $key =>$val){

        $value = new \Top\schema\value\ComplexValue();//实例化一个详情对象
        //设置值
        $inputfiled = new \Top\schema\field\InputField();//值
        if($shoptype == 'C'){
            $inputfiled->setId('value');
        }else{
            $inputfiled->setId('wap_desc_content_content');
        }
        $inputfiled->setValue($val['content']);

        //设置类型
        $typefiled = new \Top\schema\field\SingleCheckField();//类型
       // $typefiled->setId('wl_description_content_type');
        if($shoptype == 'C'){
            $typefiled->setId('type');
        }else{
            $typefiled->setId('wap_desc_content_type');
        }
        $typefiled->setValue($val['type']);

        //存入一个ComplexValue对象
        $value->put($inputfiled);
        $value->put($typefiled);

        array_push($values,$value);
        //$changefiled->addComplexValues($newvalue);//添加内容(每一个具体的值)
    }
    return $values;
}

/**
* 把pc端的详情拆分成数组
* @param $desc 要拆分的详情
* @return $arr
*/
function split_pc_desc($newdesc){

    $newmatchs = array();
   
   	$first = strpos($newdesc,'<');//标签首次出现的位置
   	if($first !== 0){//表示开始标签前面没有单独的字符串
   		$firststr = substr($newdesc,0,$first);//取出单独的文字
   		$newmatchs[] = array('content'=>$firststr,'type'=>'text');
   	}

   	if($first === false){//没有标签。全是文字
   		$newmatchs[] = array('content'=>$newdesc,'type'=>'text');
   		return $newmatchs;
   	}
   	$newdesc = preg_replace('/\s{2,}/','',$newdesc);//去除多余的空白字符
    preg_match_all('/(>(\S){1,}<)|(http(s)?:\/\/.*(?:\.png|\.gif|\.jpg))/Usi', $newdesc, $matches);
    if(!empty($matches[0])){
        foreach($matches[0] as $val){
            $newval = strip_tags($val);
            if(!empty($newval) && $newval != '>'){
                if(substr($newval,0,1) == '>'){
                    $newval = substr($newval,1);
                }
                $type = 'text';
                if(stripos($newval,'http') !== false){
                    $type = 'image';
                }
                if(stripos($newval,'id=') > 0 && stripos($newval,'item.htm') >0 ){//是宝贝连接
                    continue;
                }
                $newmatchs[] = array('content'=>$newval,'type'=>$type);
            }
        }
    }

    $end = strrpos($newdesc,'>');//标签最后出现的位置
   	$strlen = strlen($newdesc);
   	if( $end > 0 && $end != $strlen){//表示结束标签后面还有单独的字符串
   		$endstr = substr($newdesc,($end+1));//取出单独的文字
   		$newmatchs[] = array('content'=>$endstr,'type'=>'text');
   	}

    return  $newmatchs;
}


/**
* 获取一个图像的实际kb大小
* @param $uri
* @return $size kb
*/
function remote_filesize($uri){

    ob_start();
    $ch = curl_init($uri); 
    curl_setopt($ch, CURLOPT_HEADER, 1);//输出头文件信息流
    curl_setopt($ch, CURLOPT_NOBODY, 1);//不输出body内容

    $okay = curl_exec($ch);
    curl_close($ch);
    $head = ob_get_contents();//从缓冲区获取图片
    ob_end_clean(); //清除缓冲区内容
    $regex = '/Content-Length:\s([0-9].+?)\s/';//获取内容长度
    $count = preg_match($regex, $head, $matches);//正则匹配内容
    if (isset($matches[1])){
        $size = $matches[1];
        $last_kb = round($size/1024,2);
        return $last_kb;
    } else {
       return 0;
    }

}
/**
* 添加制作记录
* @param $db 数据库连接对象
* @param $userid 用户id
* @param $goodinfo 商品基本信息
* @param $res 制作结果 1，成功 2，失败
* @param $info 错误信息
* @return 
*/
function add_make_list(&$db,$userid,$goodinfo,$res,$info=''){

    $numid = $goodinfo['num_iid'];
    $outerid = isset($goodinfo['outer_id']) ? mysql_real_escape_string($goodinfo['outer_id']) : '';
    $title = isset($goodinfo['title']) ? mysql_real_escape_string($goodinfo['title']) : '';
    $picurl = isset($goodinfo['pic_url']) ? mysql_real_escape_string($goodinfo['pic_url']) : '';
    $info = mysql_real_escape_string($info);
    $sql = "REPLACE INTO `make_wireless_list`(`userid`,`numid`,`outerid`,`title`,`makeres`,`errinfo`,`picurl`) ";
    $sql .= " values ($userid,$numid,'$outerid','$title','$res','$info','$picurl')";

    $addres = $db->save($sql);
    return $addres;
}
