var page = require('webpage').create();
var args = require('system').args;//命令传过来的参数

//获取传的参数列表
var url =  args[1];
var filename = args[2];
//var width =  args[3];

var pageW = 750;//商品详情最大是750的宽度
var pageH = 960;
//可视窗口大小
page.viewportSize = {
  width: pageW,
  height: pageH
};

page.outputEncoding="utf-8";
page.open(url, function (status) {
    if (status !== 'success') {
        console.log('Unable to load ' + url + ' !');
        phantom.exit();
    } else {
        //动态渲染页面。根据html实际尺寸渲染页面
         var bb = page.evaluate(function () {
            //document.getElementById('pagewidth').style.cssText = "width:"+width;
            return document.getElementsByTagName('html')[0].getBoundingClientRect(); 
          });
        // 按照实际页面的高度，设定渲染的宽高
        page.clipRect = {
            top:    bb.top,
            left:   bb.left,
            width:  bb.width,
            height: bb.height
        };

        //预留一定的渲染时间
        window.setTimeout(function () {
       // page.clipRect = { left: 0, top: 0, width: pageW, height: pageH };
        page.render(filename);
        console.log('finish:', filename,bb.width,bb.height);//信息会输出到调用端返回
        phantom.exit();
        }, 1500);
    }
});