<?php
class TmallSellPoint implements SellPointStrategy
{
    public function getSellPoint()
    {

    }
}