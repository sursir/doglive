<?php
include 'Bar.php';

class Context
{
    public function foo()
    {
        try {
            $bar = new Bar();
            $bar->dosth();
        } catch (Exception $e) {
            echo $e, "\n--------------------\n";
        }
    }
}

$context = new Context();

$context->foo();