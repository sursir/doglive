<?php
class Bar
{
    public function dosth()
    {
        throw new Exception('xx');
    }
}

include '../Lib/CurlMulti.php';

use Lib\CurlMulti;

$urls = array(
    'a' =>'10.0.0.171',
    '10.0.0.171/pic.jpgd',
    '10.0.0.171/pic.php',
);

$opts =  array(
    CURLOPT_TIMEOUT => 2,
);

$cm = new CurlMulti();

$cm->addUrl($urls);
$cm->setOpts($opts);
$res = $cm->run();
